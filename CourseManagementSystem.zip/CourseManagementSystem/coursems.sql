-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2022 at 11:28 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coursems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `users` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `users`, `pass`) VALUES
(1, 'Olusola Oluwatosin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `codes` varchar(50) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT 'None'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `title`, `codes`, `unit`, `name`) VALUES
(1, 'Introduction to Computing ', 'COM101', '3', 'Ajinaja Micheal'),
(2, 'Computer Programming', 'COM113', '3', 'Mutiu Ganiyu'),
(3, 'Digital Electronics', 'COM112', '3', 'None'),
(4, 'Statistics Theory I', 'STA110', '2', 'None'),
(5, 'Probability Thoery', 'STA112', '2', 'Adetunji Stephen'),
(6, 'Communication Skill', 'GNS101', '2', 'Happy Chukwu'),
(7, 'Logic and Linear Graph', 'MTH101', '2', 'None'),
(8, 'Algebra Problem', 'MTH112', '2', 'None'),
(9, 'Psychology', 'GNS128', '2', 'None'),
(10, 'Use of Library', 'LIB101', '1', 'None'),
(11, 'Application Packages I', 'COM123', '3', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `users` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `course` varchar(11) DEFAULT 'None'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `name`, `users`, `pass`, `course`) VALUES
(1, 'Mutiu Ganiyu', 'ganiyu', 'ganiyu', 'COM113'),
(2, 'Fakoya Tunde', 'tunde', 'tunde', 'COM101'),
(3, 'Ajinaja Micheal', 'micheal', 'micheal', 'COM101'),
(4, 'Happy Chukwu', 'happy', 'happy', 'GNS101'),
(5, 'Adetunji Stephen', 'stephen', 'stephen', 'STA112');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
