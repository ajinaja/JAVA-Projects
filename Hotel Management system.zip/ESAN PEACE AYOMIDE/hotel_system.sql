-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2022 at 11:38 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact No` varchar(20) NOT NULL,
  `Rooms` varchar(10) NOT NULL,
  `Guests` varchar(150) NOT NULL,
  `Checkin` varchar(30) NOT NULL DEFAULT current_timestamp(),
  `Checkout` varchar(30) NOT NULL,
  `Type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`ID`, `Name`, `Address`, `Contact No`, `Rooms`, `Guests`, `Checkin`, `Checkout`, `Type`) VALUES
(9, 'Esan Peace', 'Ondo', '08140449853', 'A001', '2', 'on the 11 of may', 'on the 12 0f may', 'Suite'),
(10, 'Dipo', 'PH', '+241-442-4244', 'A002', '1', 'on the 20 of may', 'on the 21 of may', 'deluxe'),
(11, 'Praise', 'Akure', '09067255869', 'A003', '1', 'on the 1 of june', 'on the 2 of june', 'VIP'),
(12, 'HOD', 'ile oluji', '123456789', 'A004', '2', 'on the 2 of june', 'on the 7 of june', 'deluxe'),
(13, 'TOPE', 'Akure', '09023892022', 'A101', '3', 'on the 20 of may', 'on the 29 of may', 'VIP');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `roomtype` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`roomtype`, `price`) VALUES
('A001', '5000'),
('A002', '5000'),
('A003', '5000'),
('A004', '5000'),
('A006', '5000'),
('A007', '5000'),
('A008', '5000'),
('A009', '5000'),
('A100', '5000'),
('A101', '6000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`roomtype`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
