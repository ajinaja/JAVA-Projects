-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2022 at 12:06 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `java_provisons_sales_magt_system_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`username`, `password`) VALUES
('Admin', '1234'),
('Joy', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `provision_sales`
--

CREATE TABLE `provision_sales` (
  `id` int(11) NOT NULL,
  `pro_name` varchar(50) NOT NULL,
  `sprice` varchar(50) NOT NULL,
  `pprice` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `total` varchar(50) NOT NULL,
  `pro_change` varchar(50) NOT NULL,
  `payment` varchar(50) NOT NULL,
  `datee` varchar(30) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `provision_sales`
--

INSERT INTO `provision_sales` (`id`, `pro_name`, `sprice`, `pprice`, `qty`, `total`, `pro_change`, `payment`, `datee`) VALUES
(1, 'TomTom', '20', '10', '2', '200', '100', '300', '2022-06-06 13:39:51'),
(2, 'Sweat', '100', '20', '2', '200', '100', '300', '2022-06-06 13:46:30'),
(3, 'Sugar', '30', '40', '2', '60', '40', '100', '2022-06-06 15:09:01'),
(4, 'butter', '450', '29', '4', '1800', '200', '2000', '2022-06-06 15:15:30'),
(5, 'phone', '4500', '50', '4', '18000', '2000', '20000', '2022-06-06 15:22:02');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `Provision_Name` varchar(50) NOT NULL,
  `Selling_Price` varchar(50) NOT NULL,
  `Purchase_Price` varchar(50) NOT NULL,
  `Qty` varchar(50) NOT NULL,
  `Datee` varchar(30) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `Provision_Name`, `Selling_Price`, `Purchase_Price`, `Qty`, `Datee`) VALUES
(2, 'Sugar', '30', '20', '45', '2022-06-06 15:05:28'),
(3, 'butter', '450', '400', '25', '2022-06-06 15:11:59'),
(4, 'TomTom', '30', '20', '45', '2022-06-06 15:12:25'),
(5, 'phone', '4500', '3500', '46', '2022-06-06 15:19:02'),
(6, 'Cookies', '1000', '900', '2', '2022-06-08 02:21:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `provision_sales`
--
ALTER TABLE `provision_sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `provision_sales`
--
ALTER TABLE `provision_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
