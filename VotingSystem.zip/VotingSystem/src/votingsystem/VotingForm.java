/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package votingsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;



/**
 *
 * @author Admin
 */
public class VotingForm extends javax.swing.JFrame {

    /**
     * Creates new form VotingForm
     */
    public VotingForm() {
        initComponents();
        Connect();
        populatePresident();
        populateVPresident();
        populateTreasurer();
        populateSportDir();
        populateGenSecretary();
        populatePRO();
        populateFinSecretary();
    }
    int index;
    String itemSelected;
    String selected;
DefaultListModel dlm = new DefaultListModel();
int  presidentVote , vPresidentVote,Treasurer,SportDir,GenSecretary,PRO,FinSecretary;

     public void Connect(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/votingsystem","root","");
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VotingForm.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(VotingForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
     Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Votebtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        prescombo = new javax.swing.JComboBox<>();
        vcombo = new javax.swing.JComboBox<>();
        treascombo = new javax.swing.JComboBox<>();
        sportcombo = new javax.swing.JComboBox<>();
        gencombo = new javax.swing.JComboBox<>();
        procombo = new javax.swing.JComboBox<>();
        fincombo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(44, 62, 80));

        jPanel3.setBackground(new java.awt.Color(248, 178, 40));

        jLabel1.setFont(new java.awt.Font("Humnst777 Blk BT", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("VOTING SYSTEM");

        jLabel10.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("-");

        jLabel11.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("X");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(108, 108, 108)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        Votebtn.setBackground(new java.awt.Color(34, 167, 240));
        Votebtn.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        Votebtn.setForeground(new java.awt.Color(51, 51, 51));
        Votebtn.setText("Save");
        Votebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VotebtnMouseClicked(evt);
            }
        });
        Votebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VotebtnActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Please Select your Candidates");

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("President");

        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("V-President");

        jLabel5.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Treasurer");

        jLabel6.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Sport Dir.");

        jLabel7.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Gen.Secretary");

        jLabel8.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Fin. Secretary");

        jLabel9.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("P.R.O");

        jButton2.setBackground(new java.awt.Color(255, 0, 0));
        jButton2.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 51, 51));
        jButton2.setText("Exit");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        prescombo.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N

        vcombo.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N

        treascombo.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N

        sportcombo.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        sportcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sportcomboActionPerformed(evt);
            }
        });

        gencombo.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N

        procombo.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N

        fincombo.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addGap(22, 22, 22)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(vcombo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(treascombo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sportcombo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(gencombo, 0, 208, Short.MAX_VALUE)
                                    .addComponent(prescombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(30, 30, 30)
                                    .addComponent(fincombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel9)
                                    .addGap(91, 91, 91)
                                    .addComponent(procombo, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(Votebtn)
                        .addGap(77, 77, 77)
                        .addComponent(jButton2)))
                .addContainerGap(53, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(prescombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4))
                    .addComponent(vcombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(treascombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(sportcombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(gencombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(procombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(fincombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Votebtn)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        
    private void VotebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VotebtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VotebtnActionPerformed
public void populatePresident(){
        try{
            String sql = "SELECT * FROM candidate WHERE position ='President'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                prescombo.addItem(rs.getString("lname"));
                //prescombo.addItem(rs.getString("lname")+" "+rs.getString("fname")+" "+rs.getString("oname"));

            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateVPresident(){
        try{
            String sql = "SELECT lname,fname,oname FROM candidate WHERE position='VPresident'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                vcombo.addItem(rs.getString("lname")+" "+rs.getString("fname")+" "+rs.getString("oname"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateTreasurer(){
        try{
            String sql = "SELECT lname,fname,oname FROM candidate WHERE position='Treasurer'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                treascombo.addItem(rs.getString("lname")+" "+rs.getString("fname")+" "+rs.getString("oname"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateSportDir(){
        try{
            String sql = "SELECT lname,fname,oname FROM candidate WHERE position='SportDir'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                sportcombo.addItem(rs.getString("lname")+" "+rs.getString("fname")+" "+rs.getString("oname"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateGenSecretary(){
        try{
             String sql = "SELECT lname,fname,oname FROM candidate WHERE position='GenSecretary'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                gencombo.addItem(rs.getString("lname")+" "+rs.getString("fname")+" "+rs.getString("oname"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
     public void populatePRO(){
        try{
             String sql = "SELECT lname,fname,oname FROM candidate WHERE position='PRO'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                procombo.addItem(rs.getString("lname")+" "+rs.getString("fname")+" "+rs.getString("oname"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
     public void populateFinSecretary(){
        try{
             String sql = "SELECT lname,fname,oname FROM candidate WHERE position='FinSec'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                fincombo.addItem(rs.getString("lname")+" "+rs.getString("fname")+" "+rs.getString("oname"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
     public void selectVoteCountForPresident(){
        try{
            String sql = "SELECT votecount FROM candidate WHERE fname='"+prescombo.getSelectedItem()+"' AND position='President'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               presidentVote =Integer.parseInt(rs.getString("votecount"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
     public void selectVoteCountForVPresident(){
        try{
            String sql = "SELECT votecount FROM candidate WHERE fname='"+vcombo.getSelectedItem()+"' AND position='VPresident'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               vPresidentVote =Integer.parseInt(rs.getString("votecount"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
     public void selectVoteCountForTreasurer(){
        try{
            String sql = "SELECT votecount FROM candidate WHERE fname='"+treascombo.getSelectedItem()+"' AND position='Treasurer'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               Treasurer =Integer.parseInt(rs.getString("votecount"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
     public void selectVoteCountForSportDir(){
        try{
            String sql = "SELECT votecount FROM candidate WHERE fname='"+sportcombo.getSelectedItem()+"' AND position='SportDir'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
              SportDir =Integer.parseInt(rs.getString("votecount"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
     public void selectVoteCountForGenSecretary(){
        try{
            String sql = "SELECT votecount FROM candidate WHERE fname='"+gencombo.getSelectedItem()+"' AND position='GenSecretary'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               GenSecretary =Integer.parseInt(rs.getString("votecount"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForPRO(){
        try{
            String sql = "SELECT votecount FROM candidate WHERE fname='"+ procombo.getSelectedItem()+"' AND position='PRO'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               PRO =Integer.parseInt(rs.getString("votecount"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForFinSecretary(){
        try{
            String sql = "SELECT votecount FROM candidate WHERE fname='"+fincombo.getSelectedItem()+"' AND position='FinSec'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               FinSecretary =Integer.parseInt(rs.getString("votecount"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
     
      public void updateForPresident(){
        try{
            String sql = "UPDATE candidate SET votecount='"+ presidentVote +"' WHERE fname='"+prescombo.getSelectedItem()+"' AND position='President'";
            pst = con.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
       public void updateForVPresident(){
        try{
            String sql = "UPDATE candidate SET votecount='"+ vPresidentVote +"' WHERE fname='"+vcombo.getSelectedItem()+"' AND position='VPresident'";
            pst = con.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
       
        public void updateForTreasurer(){
        try{
            String sql = "UPDATE candidate SET votecount='"+ Treasurer +"' WHERE fname='"+treascombo.getSelectedItem()+"' AND position='Treasurer'";
            pst = con.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
        
        public void updateForSportDir(){
        try{
            String sql = "UPDATE candidate SET votecount='"+ SportDir +"' WHERE fname='"+sportcombo.getSelectedItem()+"' AND position='SportDir'";
            pst = con.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
        
         public void updateForGenSecretary(){
        try{
            String sql = "UPDATE candidate SET votecount='"+ GenSecretary +"' WHERE fname='"+gencombo.getSelectedItem()+"' AND position='GenSecretary'";
            pst = con.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
         
             public void updateForPRO(){
        try{
            String sql = "UPDATE candidate SET votecount='"+ PRO +"' WHERE fname='"+procombo.getSelectedItem()+"' AND position='PRO'";
            pst = con.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
             
     public void updateForFinSecretary(){
        try{
            String sql = "UPDATE candidate SET votecount='"+ FinSecretary +"' WHERE fname='"+fincombo.getSelectedItem()+"' AND position='FinSec'";
            pst = con.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void sportcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sportcomboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sportcomboActionPerformed

    private void VotebtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VotebtnMouseClicked
        if(prescombo.getSelectedIndex()==0 || vcombo.getSelectedIndex()==0 || treascombo.getSelectedIndex()==0 || sportcombo.getSelectedIndex()==0 || gencombo.getSelectedIndex()==0 || procombo.getSelectedIndex()==0 || fincombo.getSelectedIndex()==0){
               JOptionPane.showMessageDialog(null, "Please fill up all the required fields");
           }else{
                int des = JOptionPane.showConfirmDialog(null, "Finish Voting?","Confirmation",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                if(des==0){
                    selectVoteCountForPresident();
               selectVoteCountForVPresident();
               selectVoteCountForTreasurer();
               selectVoteCountForSportDir();
               selectVoteCountForGenSecretary();
               selectVoteCountForPRO();
               selectVoteCountForFinSecretary();
               
                updateForPresident();
                updateForVPresident();
                updateForTreasurer();
                updateForSportDir();
                updateForGenSecretary();
                updateForPRO();
                updateForFinSecretary();
                JOptionPane.showMessageDialog(null, "Voted Successfully!");
                }
               
           }
    }//GEN-LAST:event_VotebtnMouseClicked

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        Login l = new Login();
        close();
        l.setVisible(true);
    }//GEN-LAST:event_jButton2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VotingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VotingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VotingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VotingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VotingForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Votebtn;
    private javax.swing.JComboBox<String> fincombo;
    private javax.swing.JComboBox<String> gencombo;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JComboBox<String> prescombo;
    private javax.swing.JComboBox<String> procombo;
    private javax.swing.JComboBox<String> sportcombo;
    private javax.swing.JComboBox<String> treascombo;
    private javax.swing.JComboBox<String> vcombo;
    // End of variables declaration//GEN-END:variables

    private void close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
