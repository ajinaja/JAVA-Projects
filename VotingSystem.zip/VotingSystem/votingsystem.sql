-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2022 at 01:45 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `id` int(11) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `oname` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `age` varchar(3) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `position` varchar(50) NOT NULL,
  `votecount` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`id`, `lname`, `fname`, `oname`, `address`, `age`, `gender`, `position`, `votecount`) VALUES
(1, 'geef', ' cfvrg', 'grfgr ', ' brfed', ' br', ' breg', ' grbver', ''),
(2, 'Wilson', ' Ezeala', 'Fedpolel', ' efrferfe', ' 23', ' Male', ' President', ''),
(3, 'Sheyi', ' Iroko', ' David', ' nfedwe', ' 19', 'Male ', ' Treasurer', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `matno` varchar(20) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `oname` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `age` varchar(3) NOT NULL,
  `gender` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`matno`, `lname`, `fname`, `oname`, `address`, `age`, `gender`) VALUES
('feff', 'fe', ' fe', ' fef', ' fge', ' wr', ' fwf'),
('FPI/CSC/20/026', 'Wilson', 'Ezeala', 'Fedpolel', 'fcdced', '34', 'Male'),
('FPI/CSC/20/028', 'Wilson', 'Ezeala', 'Fedpolel', 'fcdced', '34', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`matno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
