-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 07:42 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentreg`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `matricnumber` int(11) NOT NULL,
  `firstname` int(11) NOT NULL,
  `othername` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `studenttable`
--

CREATE TABLE `studenttable` (
  `id` int(11) NOT NULL,
  `matricnumber` varchar(50) NOT NULL,
  `surnname` varchar(50) NOT NULL,
  `othernames` varchar(100) NOT NULL,
  `phoneno` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `local` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `bith` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `course` varchar(50) NOT NULL,
  `award` varchar(50) NOT NULL,
  `extra` varchar(50) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `mode` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `kinname` varchar(100) NOT NULL,
  `relationship1` varchar(50) NOT NULL,
  `kinphoneno` varchar(50) NOT NULL,
  `sponsor` varchar(100) NOT NULL,
  `relationship2` varchar(50) NOT NULL,
  `sponsorphoneno` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studenttable`
--

INSERT INTO `studenttable` (`id`, `matricnumber`, `surnname`, `othernames`, `phoneno`, `gender`, `state`, `local`, `place`, `bith`, `address`, `course`, `award`, `extra`, `faculty`, `mode`, `department`, `kinname`, `relationship1`, `kinphoneno`, `sponsor`, `relationship2`, `sponsorphoneno`) VALUES
(2, 'fpi/csc/20/011', 'gjgj', 'gjhg', 'jgfjh', 'fhj', 'hj', 'gfj', 'jhgfh', 'gfhjg', 'fhj', '2yrsghj', 'gjh', 'gjh', 'uy', 'utuy', 'tuu', 'iuyi', 'iuyi', 'uyiu', 'iu', 'iu', 'iut'),
(3, '', '', '', '', '', '', '', '', '', '', '2yrs', '', '', '', '', '', '', '', '', '', '', ''),
(4, 'iug', 'iu', 'uhiu', 'hiuh', 'jhij', 'igi', 'iuhi', 'hiu', 'iuhi', 'jhij', '2yrsi', 'ihi', 'h', 'jhbg', 'jgjh', 'gkkj', 'jkghkj', 'jkghkj', 'gh', 'hkj', 'hkj', 'hkj');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'gold', 'gold'),
(2, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studenttable`
--
ALTER TABLE `studenttable`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `matricnumber` (`matricnumber`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `studenttable`
--
ALTER TABLE `studenttable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
